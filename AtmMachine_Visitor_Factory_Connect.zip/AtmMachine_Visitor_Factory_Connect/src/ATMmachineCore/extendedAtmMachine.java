package ATMmachineCore;

import interfaceAtmState.AtmState;
import interface_visitor.Visitable;
import interface_visitor.Visitor;
//////////////////------------> new
public class extendedAtmMachine extends ATMmachine implements Visitable {
	
	public AtmState getAtmState()
	{
		return (atmState);
			
	}
	public double getcashInMachine()
	{
		return cashInMachine ;
	}

	@Override
	public double accept(Visitor visitor) {
		// TODO Auto-generated method stub
		return visitor.Visit(this);
		
	}

}
