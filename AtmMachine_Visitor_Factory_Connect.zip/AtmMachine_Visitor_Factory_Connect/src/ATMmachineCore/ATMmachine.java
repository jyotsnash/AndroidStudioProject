package ATMmachineCore;

import MyriadAtmStates.HasCard;
import MyriadAtmStates.HasPin;
import MyriadAtmStates.NoCard;
import interfaceAtmState.AtmState;
import interface_visitor.Visitable;
import interface_visitor.Visitor;

public class ATMmachine { //implements Visitable {
	
	
	AtmState hasCard ;
	AtmState noCard ;
	AtmState hasCorrectPin ;
	AtmState atmOutOfMoney ;
	
	AtmState atmState ;
	
	public int cashInMachine = 5000 ;
	public boolean correctPinEntered = false ;
	
	
	public ATMmachine() {
		// TODO Auto-generated constructor stub
		
		hasCard = new HasCard( this) ;
		noCard = new NoCard( this) ;
		hasCorrectPin = new HasPin(this) ;
		atmOutOfMoney = new NoCard(this);
		
		
		atmState = noCard; // current state says noCard
		
		if( cashInMachine < 0 ){
			atmState = atmOutOfMoney ;
			
		}
	}

	public void setAtmState( AtmState newAtmState)
	{
		atmState = newAtmState;
			
	}
	
	public void setCashInMachine( int newCashInMachine )
	{
		cashInMachine = newCashInMachine;
		
	}
		
	public void insertCard()
	{
		atmState.insertCard();// nocard
	}
	
	public void requestCash( int CashToWithdraw)
	{
		atmState.requestCash(CashToWithdraw);
	}
	
	public void ejectCard()
	{
		atmState.ejectCard(); // hascard
	}
	public void insertPin(int pinEntered)
	{
		atmState.insertPin(pinEntered);
	}
	
	
	public AtmState getYesCardState() { return hasCard ; }
	public AtmState getNoCardState() { return noCard; }
	public AtmState getHasPin() { return hasCorrectPin ; }
	public AtmState getNoCashState() { return atmOutOfMoney ; }
	
	
	
//	//////////////////------------> new
	/////////////////////////       decoupled it from here to extendedAtmMachine class
//	public AtmState getAtmState()
//	{
//		return (atmState);
//			
//	}
//	public double getcashInMachine()
//	{
//		return cashInMachine ;
//	}
//
//	@Override
//	public double accept(Visitor visitor) {
//		// TODO Auto-generated method stub
//		return visitor.Visit(this);
//		
//	}
}
