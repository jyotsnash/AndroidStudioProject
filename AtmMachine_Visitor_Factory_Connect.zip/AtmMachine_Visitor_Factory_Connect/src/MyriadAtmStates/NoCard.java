package MyriadAtmStates;

import ATMmachineCore.ATMmachine;
import interfaceAtmState.AtmState;

public class NoCard  implements AtmState{

	ATMmachine atmMachine ;
	
	public NoCard( ATMmachine   newATMmachineCore ) {
		// TODO Auto-generated constructor stub
		atmMachine = newATMmachineCore ;
	}
	@Override
	public void insertCard() {
		// TODO Auto-generated method stub
		System.out.println("Please Enter your Pin");
		atmMachine.setAtmState(atmMachine.getYesCardState());
		
	}

	@Override
	public void ejectCard() {
		// TODO Auto-generated method stub
		System.out.println("you dint't enter a card");
	}

	@Override
	public void insertPin( int pinEntered) {
		// TODO Auto-generated method stub
		System.out.println("you dint't enter a card");
	}

	@Override
	public void requestCash(int cashToWithDraw) {
		// TODO Auto-generated method stub
		System.out.println("you dint't enter a card");
	}



}
