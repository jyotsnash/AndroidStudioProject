package MyriadAtmStates;

import ATMmachineCore.ATMmachine;
import interfaceAtmState.AtmState;

public class HasPin  implements AtmState{
ATMmachine atmMachine ;
	
	public HasPin( ATMmachine   newATMmachineCore ) {
		// TODO Auto-generated constructor stub
		atmMachine = newATMmachineCore ;
	}
	@Override
	public void insertCard() {
		// TODO Auto-generated
		System.out.println("You already entered a card");
	}

	@Override
	public void ejectCard() {
		// TODO Auto-generated method stub
		System.out.println("Your card is Ejected");
		atmMachine.setAtmState(atmMachine.getNoCardState());

		
	}

	@Override
	public void insertPin(int  pinEntered) {
		// TODO Auto-generated method stub
		System.out.println("You have already inserted the pin");
		
		
	}

	@Override
	public void requestCash( int cashToWithDraw) {
		// TODO Auto-generated method stub
		if( cashToWithDraw > atmMachine.cashInMachine)
		{
			System.out.println("You dont have so much of cash available");
			System.out.println("Your card is ejected");
			atmMachine.setAtmState(atmMachine.getNoCardState());
			
				
		}
		System.out.println(cashToWithDraw + " is provided by the machine");
         atmMachine.setCashInMachine(atmMachine.cashInMachine - cashToWithDraw);
			System.out.println("Your card is ejected");
			
			atmMachine.setAtmState(atmMachine.getNoCardState());
			
			if( atmMachine.cashInMachine <= 0)
			{
				atmMachine.setAtmState(atmMachine.getNoCashState());
			}

		
	}


}
