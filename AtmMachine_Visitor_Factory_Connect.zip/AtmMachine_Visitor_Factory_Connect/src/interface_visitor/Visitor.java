package interface_visitor;

import ATMmachineCore.ATMmachine;
import ATMmachineCore.extendedAtmMachine;

public interface Visitor {
	//public double Visit(ATMmachine atm );
	public double Visit( extendedAtmMachine atm);

}
