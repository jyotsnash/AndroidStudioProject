package interface_visitor;

public interface Visitable {
	public double accept( Visitor visitor);

}
