package AtmMachine;

import ATMmachineCore.ATMmachine;
import ATMmachineCore.extendedAtmMachine;
import MyfactoryConnect.myFactory;

public class FireAtmMachine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 ATMmachine atmMachine = new ATMmachine(); 
		 
		 atmMachine.insertCard();
		 atmMachine.ejectCard();
		 
		 atmMachine.insertCard();  // has card 
		 atmMachine.insertPin(1234);  // has pin
		 
		 atmMachine.requestCash(1500);
		 atmMachine.insertCard();
		 atmMachine.insertPin(1234);
		 
	/////////////////////---- New	

		 //ATMmachine atmMachine = new ATMmachine(); 
		 
		 
		 extendedAtmMachine eatmMachine = new extendedAtmMachine();
		 myFactory mf = new myFactory();
		eatmMachine.accept(mf);
	}

}
