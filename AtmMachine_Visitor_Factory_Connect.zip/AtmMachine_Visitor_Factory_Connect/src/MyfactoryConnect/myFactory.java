package MyfactoryConnect;

import ATMmachineCore.ATMmachine;
import ATMmachineCore.extendedAtmMachine;
import interfaceAtmState.AtmState;
import interface_visitor.Visitor;

public class myFactory implements Visitor{

	//atm.accept(this);
	
	@Override
	public double Visit(extendedAtmMachine atm) {
		// TODO Auto-generated method stub
		System.out.println(" AtmState is Displayed from myFactory... : " + atm.getAtmState());
		
		atm.getAtmState();
		
		System.out.println(" Cash in machine : " + atm.getcashInMachine());
		System.out.println(" Since we have atm handle we can use complete atmMachine functionality : " );
		
		System.out.println(" Watch we have called setCashInMachine(8000) !!!\n " );
		
		System.out.println(" cant you smell a rAt!!! a - Malicious behaviour!!!  : " );
		System.out.println("\n Lets quell this behaviour by wraping AtmMachine by Proxy. \n"
				+ "It stands like a fire wall Limiting the controll...");
		
				atm.setCashInMachine(8000);
		
		System.out.println(" After calling  atm.setCashInMachine(8000); : Cash in machine : " + atm.getcashInMachine());
		
		return 0;
		
	}
}
