package projects.chythanya.viewmodeldagger.DI;

import javax.inject.Singleton;

import dagger.Component;
import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;
import projects.chythanya.viewmodeldagger.View.MainActivity;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;

//only Single instance of the interface is created
//it acts as a bridge between the provider(module) and the consumer(mainActivity)


/*
A Component is a mapping between one or more modules and one or more classes that will use them.
In this particular case, we have a single module,
BookComponent, that is being used by a single class, MainActivity.
 */
@Singleton
@Component(modules = BookModule.class)
public interface BookComponent {
//this is the method we are injecting into mainactivity
    ViewModelFactory provideViewModelFactory();
    void inject(MainActivity main);//here we can add all the activities/fragments which needs injecting
}
