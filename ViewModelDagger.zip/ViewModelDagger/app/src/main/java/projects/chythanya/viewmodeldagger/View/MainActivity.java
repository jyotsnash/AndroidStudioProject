package projects.chythanya.viewmodeldagger.View;

import android.arch.lifecycle.ViewModelProviders;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import projects.chythanya.viewmodeldagger.DI.BookComponent;
import projects.chythanya.viewmodeldagger.DI.DaggerBookComponent;
import projects.chythanya.viewmodeldagger.R;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;
import projects.chythanya.viewmodeldagger.ViewModel.bookViewModel;

public class MainActivity extends AppCompatActivity {


    private bookViewModel bookViewModel;

    @BindView(R.id.bookTitle)
    protected TextView bookTitle;

    @BindView(R.id.bookAuthor)
    protected TextView bookAuthor;

    /*


    The @Inject annotation
    We have many annotation to choose from to solve the problem. The @Provides annotation offers more possibilities
    than @Inject but requires more code. Thus, in the following section, we specify the dependency graph only with
     @Inject annotation.


     */
    @Inject
    ViewModelFactory factory;        // press CTRL + click to check what it is providing
    //                               bookViewModel = ViewModelProviders.of(this,factory).get(bookViewModel.class);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BookComponent component = DaggerBookComponent.builder().build();
        component.inject(this);

        ButterKnife.bind(this);

        bookViewModel = ViewModelProviders.of(this,factory).get(bookViewModel.class);

        bookTitle.setText(bookViewModel.getTitle());
        bookAuthor.setText(bookViewModel.getAuthor());
    }
}
