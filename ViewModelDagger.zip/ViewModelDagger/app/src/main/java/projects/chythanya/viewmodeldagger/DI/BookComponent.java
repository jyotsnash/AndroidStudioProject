package projects.chythanya.viewmodeldagger.DI;

import javax.inject.Singleton;

import dagger.Component;
import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;
import projects.chythanya.viewmodeldagger.View.MainActivity;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;

@Singleton
@Component(modules = BookModule.class)
public interface BookComponent {

    ViewModelFactory provideViewModelFactory();

    void inject(MainActivity main);
}
