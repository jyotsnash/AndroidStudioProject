package projects.chythanya.viewmodeldagger.ViewModel;

import android.arch.lifecycle.ViewModel;

import projects.chythanya.viewmodeldagger.Model.repository;

public class bookViewModel extends ViewModel {

    private repository repository;

    bookViewModel(repository repo){
        repository = repo;
    }

   public String getTitle(){
       String title = repository.getTitle();
       return title;
    }
    public String getAuthor(){
      return  repository.getAuthor();
    }
}
