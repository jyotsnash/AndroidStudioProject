package projects.chythanya.viewmodeldagger.DI;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;
import projects.chythanya.viewmodeldagger.View.MainActivity;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;
import projects.chythanya.viewmodeldagger.ViewModel.bookViewModel;

@Module
public class BookModule {

    @Provides
    @Singleton
    Book provideBook() {
        return new Book();
    }

    @Provides
    @Singleton
    repository providerepository(){
        return new repository(new Book());

    }
    @Provides
    @Singleton
    ViewModelFactory providefactory(){
        return new ViewModelFactory(new repository (new Book()));
    }


}
