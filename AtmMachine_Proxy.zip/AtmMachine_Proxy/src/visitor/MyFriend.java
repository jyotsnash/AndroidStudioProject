package visitor;

import FireWall_Via_Proxy.atmProxy;
import extendedATM.ExtendedAtmMachine;
import iVisitor.Visitor;
/*
 * Instead of Visitng ATMMAchine, we are visiting atmProxy.
 */
public class MyFriend implements Visitor{

	@Override
	public double visit(atmProxy atm) {
		
		// TODO Auto-generated method stub
		System.out.println("Atm state is displayed in MyFriend class" + atm.getAtmState());
		System.out.println("Cash in machine is: " + atm.getCashInMachine());
		//atm.setCashInMachine(0);
		System.out.println("set cash in machine, we are not the bankers" + atm.getCashInMachine());
		return 0;
	}

}
