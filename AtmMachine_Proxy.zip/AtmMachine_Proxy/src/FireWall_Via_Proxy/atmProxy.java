package FireWall_Via_Proxy;

import ATMmachineCore.ATMmachine;
import Proxy_Interface.GetAtmData;
import interfaceAtmState.AtmState;

public class atmProxy implements GetAtmData{

	@Override
	public AtmState getAtmState() {
		// TODO Auto-generated method stub
		ATMmachine atmMachine = new ATMmachine();
		return atmMachine.atmState;
	}

	@Override
	public double getCashInMachine() {
		// TODO Auto-generated method stub
		ATMmachine atmMachine = new ATMmachine();
		return atmMachine.cashInMachine;
	}
	 
}