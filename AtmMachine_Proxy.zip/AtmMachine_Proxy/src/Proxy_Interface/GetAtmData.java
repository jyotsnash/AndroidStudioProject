package Proxy_Interface;

import interfaceAtmState.AtmState;
/*
 * Wrapper for our ATM Machine.
 */
public interface GetAtmData {
 public AtmState getAtmState();
 public double getCashInMachine();
}
