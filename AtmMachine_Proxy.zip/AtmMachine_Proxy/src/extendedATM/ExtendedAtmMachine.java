package extendedATM;

import ATMmachineCore.ATMmachine;
import FireWall_Via_Proxy.atmProxy;
import Proxy_Interface.GetAtmData;
import iVisitor.Visitiable;
import iVisitor.Visitor;
import interfaceAtmState.AtmState;

/*
 * instead of extending atmmachine, we are extending atmProxy
 */
public class ExtendedAtmMachine extends atmProxy implements Visitiable{

	@Override
	public double accept(Visitor visitor) {
		// TODO Auto-generated method stub
		return visitor.visit(this);
	}
	
	

}
