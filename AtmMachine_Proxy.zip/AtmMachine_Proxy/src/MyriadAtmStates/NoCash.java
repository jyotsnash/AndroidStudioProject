package MyriadAtmStates;

import ATMmachineCore.ATMmachine;
import interfaceAtmState.AtmState;

public class NoCash  implements AtmState{
ATMmachine atmMachine ;
	
	public NoCash( ATMmachine   newATMmachineCore ) {
		// TODO Auto-generated constructor stub
		atmMachine = newATMmachineCore ;
	}
	@Override
	public void insertCard() {
		// TODO Auto-generated method stub
		System.out.println("You don't have any money");
		
		
	}

	@Override
	public void ejectCard() {
		// TODO Auto-generated method stub
		System.out.println("You dont have any money");
		System.out.println("There is no card to eject");
		
		
	}

	@Override
	public void insertPin( int pinEntered) {
		// TODO Auto-generated method stub
		System.err.println("We dont have any money");
		
	}

	@Override
	public void requestCash( int cashToWithdraw) {
		// TODO Auto-generated method stub
		System.err.println("We dont have any money");
		
		
	}


}
