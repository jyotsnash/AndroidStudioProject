package MyriadAtmStates;

import ATMmachineCore.ATMmachine;
import interfaceAtmState.AtmState;

public class HasCard implements AtmState{
	
	ATMmachine atmMachine ;

	public HasCard( ATMmachine   newATMmachineCore ) {
		// TODO Auto-generated constructor stub
		atmMachine = newATMmachineCore ;
	}

	@Override
	public void insertCard() {
		// TODO Auto-generated method stub
		
		System.out.println("Card can be inserted only once");
		
		
	}

	@Override
	public void ejectCard() {
		// TODO Auto-generated method stub
		System.out.println(" your card is ejected");
		atmMachine.setAtmState(atmMachine.getNoCardState());
		
		
	}

	@Override
	public void insertPin( int pinEntered) {
		// TODO Auto-generated method stub
		if( pinEntered == 1234 )
		{
			System.out.println("You entered the correct pin");
			atmMachine.correctPinEntered = true ;
			atmMachine.setAtmState(atmMachine.getHasPin());
			
				
		}
		else
		{
		System.out.println("You entered wrong Pin");
		atmMachine.correctPinEntered = false ;
		System.out.println("Your card is ejected");
		atmMachine.setAtmState(atmMachine.getNoCardState());
		}
		
		
		
		
	}

	@Override
	public void requestCash(int cashToWithdraw) {
		// TODO Auto-generated method stub
		System.out.println("You  have not entered your Pin");
		
	}

}
