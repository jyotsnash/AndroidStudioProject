package iVisitor;

import FireWall_Via_Proxy.atmProxy;
import extendedATM.ExtendedAtmMachine;

public interface Visitor {
	public double visit(atmProxy atm);
	//public double visit(ExtendedAtmMachine atm);
}
