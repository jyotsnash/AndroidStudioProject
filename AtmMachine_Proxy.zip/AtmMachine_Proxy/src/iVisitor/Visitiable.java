package iVisitor;

public interface Visitiable {
	public double accept(Visitor visitor);
}
