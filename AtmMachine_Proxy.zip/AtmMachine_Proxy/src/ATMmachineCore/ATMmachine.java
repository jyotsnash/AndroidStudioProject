package ATMmachineCore;

import MyriadAtmStates.HasCard;
import MyriadAtmStates.HasPin;
import MyriadAtmStates.NoCard;
//import Proxy_Interface.ATMState;

import interfaceAtmState.AtmState;

public class ATMmachine { //implements GetAtmData{
	
	
	AtmState hasCard ;
	AtmState noCard ;
	AtmState hasCorrectPin ;
	AtmState atmOutOfMoney ;
	
	public AtmState atmState ;
	
	public int cashInMachine         = 5000  ;
	public boolean correctPinEntered = false ;
	
	
	public ATMmachine() {
		// TODO Auto-generated constructor stub
		
		hasCard        = new HasCard( this) ;  // composition...
		noCard         = new NoCard( this) ;
		hasCorrectPin  = new HasPin(this) ;
		atmOutOfMoney  = new NoCard(this);
		
		
		atmState = noCard;                    // current state says noCard
		
		if( cashInMachine <= 0 ){
			atmState = atmOutOfMoney ;
			
		}
	}

	public void setAtmState( AtmState newAtmState)
	{
		atmState = newAtmState;
			
	}
	
	public void setCashInMachine( int newCashInMachine )
	{
		cashInMachine = newCashInMachine;
		
	}
		
	
	public void insertCard()
	{
		atmState.insertCard();// nocard.insertCard();
	}
	
	public void requestCash( int CashToWithdraw)
	{
		atmState.requestCash(CashToWithdraw);
	}
	
	public void ejectCard()
	{
		atmState.ejectCard(); // hascard
	}
	public void insertPin(int pinEntered)
	{
		atmState.insertPin(pinEntered);
	}
	
	
	public AtmState getYesCardState() { return hasCard ; }
	public AtmState getNoCardState() { return noCard; }
	public AtmState getHasPin() { return hasCorrectPin ; }
	public AtmState getNoCashState() { return atmOutOfMoney ; }
	
	
	
	
	
	
	
	
	
	
	
	
}
