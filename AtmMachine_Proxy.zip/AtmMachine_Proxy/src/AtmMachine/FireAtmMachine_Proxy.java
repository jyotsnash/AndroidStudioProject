package AtmMachine;

import ATMmachineCore.ATMmachine;
import Proxy_Interface.GetAtmData;
import extendedATM.ExtendedAtmMachine;
import visitor.MyFriend;

public class FireAtmMachine_Proxy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 ATMmachine atmMachine = new ATMmachine(); 
		 
		 
		 //atmMachine.requestCash(300);
		 
		 
		 
		 //atmMachine.insertCard();
		 //atmMachine.ejectCard();
		 
		 //atmMachine.insertCard();  // has card 
		 //atmMachine.insertPin(1234);  // has pin
		 
		 //atmMachine.requestCash(1500);
		 //atmMachine.insertCard();
		 //atmMachine.insertPin(1234);
		 
		 //GetAtmData AtmMachine = new 
		 GetAtmData atmProxy = new FireWall_Via_Proxy.atmProxy();
		 System.out.println("Current ATM State via firewall" + atmProxy.getAtmState());
		 System.out.println("Get cash in machine : "+ atmProxy.getCashInMachine());
		 //atmProxy.
		 //ExtendedAtmMachine extendedAtmMachine = new ExtendedAtmMachine();
		 //MyFriend myFriend = new MyFriend();
		 
		 //extendedAtmMachine.accept(myFriend);
		 
	}

}
