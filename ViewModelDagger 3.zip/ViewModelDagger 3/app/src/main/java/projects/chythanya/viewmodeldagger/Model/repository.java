package projects.chythanya.viewmodeldagger.Model;

import javax.inject.Inject;

public class repository {
    // Idea of this repository is to branch out to many verticales
    private Book mbook;


   public repository(Book book){
        mbook = book;
        mbook.setTitle("Book title");
        mbook.setAuthor("Book Author");
    }

public String getTitle(){
        String title = mbook.getTitle();
        return title;
}
public String getAuthor(){
        return mbook.getAuthor();
}
}
