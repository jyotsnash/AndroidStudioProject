package projects.chythanya.viewmodeldagger.DI;


import android.app.Application;
//aplication class to be used to access the component across Activities like the way its accessed by MainActivity
public class MyApplication extends Application {
    private BookComponent component;

    @Override
    public void onCreate() {
        super.onCreate();
        component = createMyComponent();
    }

    public BookComponent getComponent(){
        return component;
    }

    private BookComponent createMyComponent() {

        return DaggerBookComponent.builder().
                bookModule(new BookModule()).
                build();//builds the component
    }
}
