package projects.chythanya.viewmodeldagger.DI;

import javax.inject.Singleton;

import dagger.Component;
import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;
import projects.chythanya.viewmodeldagger.View.MainActivity;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;

//only cingle instance of the interface is created
//it acts as a bridge between the provider(module) and the consumer(mainActivity)

@Singleton
@Component(modules = BookModule.class)
public interface BookComponent {
//this is the method we are injecting into mainactivity
    ViewModelFactory provideViewModelFactory();
    void inject(MainActivity main);//here we can add all the activities/fragments which needs injecting
    //  void inject( MainActivityTwo  mainActivityTWO );//here we can add all the activities/fragments which needs injecting
}
