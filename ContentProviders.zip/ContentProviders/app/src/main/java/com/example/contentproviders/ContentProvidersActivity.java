package com.example.contentproviders;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.EditText;

/*
<activity
            android:name=".ContentProvidersActivity"
            android:label="@string/app_name">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

 */
public class ContentProvidersActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);				
	}
	
	public void onClickAddTitle(View view) {
		//---add a movie---
		ContentValues values = new ContentValues();

		values.put(MoviesProvider.TITLE, ((EditText)findViewById(R.id.txtTitle)).getText().toString());
		values.put(MoviesProvider.DIRECTOR, ((EditText)findViewById(R.id.txtDirector)).getText().toString());
		
		//for external packages use the fully qualified URI 
		//Uri.parse("content://com.example.provider.Movies/movies")		

		 Uri uri = getContentResolver().insert(MoviesProvider.CONTENT_URI, values);


		Toast.makeText(getBaseContext(), uri.toString(), Toast.LENGTH_LONG).show();
	}
			
	@SuppressLint("NewApi")
	public void onClickRetrieveTitles(View view) {
		//---retrieve the titles---
		Uri allTitles = Uri.parse("content://com.example.provider.Movies/movies/");
		//1 content : standerd prefix
		// 2 .b.c.d.Movies :  Authority
		// 3. Data path - movieIndex - subcat
		// 4.  id
		
		Cursor c;
		
		//return the result sorted in descending order based on the title field
		if (android.os.Build.VERSION.SDK_INT <11) {
			//---pre Honeycomb---
			c = managedQuery(allTitles, null, null, null, "title DESC");
		} 
		else {
			//---Honeycomb and later---
			CursorLoader cursorLoader = new CursorLoader(
													this,
													allTitles, null, null, null,
													"title DESC");
			c = cursorLoader.loadInBackground();
		}
		
		if (c.moveToFirst()) {
			do{
				Toast.makeText(this, 
						c.getString(c.getColumnIndex(MoviesProvider._ID)) + ", " +
						c.getString(c.getColumnIndex(MoviesProvider.TITLE)) + ", " +
						c.getString(c.getColumnIndex(MoviesProvider.DIRECTOR)),
						Toast.LENGTH_SHORT).show();
			} 
			while (c.moveToNext());
		}
	}
	
	public void onClickUpdateTitle(View view) {
		//---update a title---
		ContentValues editedValues = new ContentValues();
		editedValues.put(MoviesProvider.TITLE, "New Movie Title");

		int c = getContentResolver().update(
					Uri.parse("content://com.example.provider.Movies/movies/2"),
					editedValues,
					null,
					null);
		if(c == 0) {
			Toast.makeText(this, "No record found!", Toast.LENGTH_LONG).show();
		}
		else {
			Toast.makeText(this, "" + c + " record updated!", Toast.LENGTH_LONG).show();
		}
	}
	
	public void onClickDeleteTitle(View view) {
		//---delete a title---
		int c = getContentResolver().delete(
					Uri.parse("content://com.example.provider.Movies/movies/1"),
					null, 
					null);
		
		if(c == 0) {
			Toast.makeText(this, "No record found!", Toast.LENGTH_LONG).show();
		}
		else {
			Toast.makeText(this, "" + c + " record deleted!", Toast.LENGTH_LONG).show();
		}
	}
	
	public void onClickDeleteAllTitle(View view) {
		//---delete a title---
		int c = getContentResolver().delete(
					Uri.parse("content://com.example.provider.Movies/movies"),
					null, 
					null);
		
		if(c == 0) {
			Toast.makeText(this, "No records found!", Toast.LENGTH_LONG).show();
		}
		else {
			Toast.makeText(this, "" + c + " records deleted!", Toast.LENGTH_LONG).show();
		}
	}
}