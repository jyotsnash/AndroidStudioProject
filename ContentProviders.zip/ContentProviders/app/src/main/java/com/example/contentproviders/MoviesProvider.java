package com.example.contentproviders;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import static android.provider.Settings.Global.CONTENT_URI;
/*

It's good practice to provide the extra level of abstraction over your data to make it easier to change internally.
 What if you decide to change the underlying database structure at a later time?
 If you use a ContentProvider you can contain all the structural changes within it,

  where as if you don't use one, you are forced to change all areas of the
  code that are affected by the structural changes.

  Besides, it's nice to be able to re-use the same standard API for
  accessing data rather than littering your code with low-level access to the database.


 */

public class MoviesProvider extends ContentProvider {
	static final String PROVIDER_NAME = "com.example.provider.Movies";

	// Uri path
//	//SMS_INBOX = Uri.parse("content://sms/inbox");
//                                          /outBox
//	                                       Sent
//			                                Deleted
	static final Uri CONTENT_URI = Uri.parse("content://"+ PROVIDER_NAME + "/movies/");
	  //                                                                      /english

	//////



	////////


	static final String _ID        = "_id"     ;
	static final String TITLE      = "title"   ;
	static final String DIRECTOR   = "director";

	static final int MOVIES        = 1         ;
	static final int MOVIE_ID      = 2         ;



	// Set it up for the content provider
	private static final UriMatcher uriMatcher;

	static{
		uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		uriMatcher.addURI(PROVIDER_NAME, "movies", MOVIES);

		uriMatcher.addURI(PROVIDER_NAME, "movies/#", MOVIE_ID);



	}

	// Regular SQL Stuff
	//---for database use---
	SQLiteDatabase moviesDB;

	static final String DATABASE_NAME    = "Movies";
	static final String DATABASE_TABLE   = "titles";
	static final int DATABASE_VERSION    = 3;//1;
	static final String DATABASE_CREATE  =
								"create table " + DATABASE_TABLE +
								" (_id integer primary key autoincrement, "
								+ "title text not null, director text not null);";
								
	private static class DatabaseHelper extends SQLiteOpenHelper {
		
		DatabaseHelper(Context context) {

			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
		
		@Override
		public void onCreate(SQLiteDatabase db){
			db.execSQL(DATABASE_CREATE);
		}
		
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w("Contentdatabase",
					"Upgrading database from version " 
							+ oldVersion + " to " + newVersion 
							+ ", which will destroy all old data");
			
			db.execSQL("DROP TABLE IF EXISTS titles");
			onCreate(db);
		}		
	}
	
	@Override
	public boolean onCreate() {
		Context context = getContext();
		
		//open a connection to the database when the content
		//provider is started
		DatabaseHelper dbHelper = new DatabaseHelper(context);
		moviesDB = dbHelper.getWritableDatabase();
		
		return (moviesDB == null)? false:true;
	}


	// Content Provider Wrapper...

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {		
		int count=0;
		switch (uriMatcher.match(uri)){  // remember this returns URI TYPE ie.,
			case MOVIES:                   // case MOVIES:	return "vnd.android.cursor.dir/vnd.example.movies";
					count = moviesDB.delete(
									DATABASE_TABLE,
									selection,
									selectionArgs);
			break;
			case MOVIE_ID:  // return "vnd.android.cursor.item/vnd.example.movies";
				String id = uri.getPathSegments().get(1);
				count = moviesDB.delete(
									DATABASE_TABLE,
									_ID + " = " + id +
									(!TextUtils.isEmpty(selection) ? " AND (" +
											selection + ')' : ""),
											selectionArgs);
				break;
			default: throw new IllegalArgumentException("Unknown URI " + uri);
		}

		// report the change to master
		getContext().getContentResolver().notifyChange(uri, null);
		return count;
	}

	// vnd.android.cursor.dir/vnd.myexample.whatever
	//  "vnd" stands for vendor in MIME Registration trees in  android

	/*
	TODO: NOTE :
	 getType(Uri uri) will usually only be called after a call to ContentResolver#getType(Uri uri).
	It is used by applications (either other third-party applications, if your ContentProvider has been exported,
	 or your own) to retrieve the MIME type of the given content URL. If your app isn't concerned with the data's MIME type,
	 it's perfectly fine to simply have the method return null.


	 */

	@Override
	public String getType(Uri uri) {
		switch (uriMatcher.match(uri)){
			//---get all movies---
			case MOVIES:
				Toast.makeText(getContext(), "MOVIES : returning MOVIES vnd ", Toast.LENGTH_SHORT).show();
				return "vnd.android.cursor.dir/vnd.example.movies";   // watch for dir
			//---get a particular movie---
			case MOVIE_ID:
				return "vnd.android.cursor.item/vnd.example.movies";  // item
			default:
				throw new IllegalArgumentException("Unsupported URI: " + uri);
		}
	}
	
	@Override
	public Uri insert(Uri uri, ContentValues values) {
		//---add a new movie---
		long rowID = moviesDB.insert(
								DATABASE_TABLE,
								"",
								values);
		Toast.makeText(getContext(), "...Inserted in Row "+rowID, Toast.LENGTH_SHORT).show();
		
		//---if added successfully---
		if (rowID > 0){
			Uri _uri = null; //
			if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
				_uri = ContentUris.withAppendedId(CONTENT_URI, rowID);
			}
			getContext().getContentResolver().notifyChange(_uri, null);
			return _uri;
		}


		throw new SQLException("Failed to insert row into " + uri);
	}
		
	
	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
		String[] selectionArgs, String sortOrder) {
		
		SQLiteQueryBuilder sqlBuilder = new SQLiteQueryBuilder();
		sqlBuilder.setTables(DATABASE_TABLE);
		
		if (uriMatcher.match(uri) == MOVIE_ID)
			//---if getting a particular movie---
			sqlBuilder.appendWhere(_ID + " = " + uri.getPathSegments().get(1));
		
		if (sortOrder == null || sortOrder == "") {
			//If no ORDER BY parameter is passed
			//the result of the query is sorted using the title field
			sortOrder = TITLE;
		}
		
		Cursor c = sqlBuilder.query(
								moviesDB,
								projection,
								selection,
								selectionArgs,
								null,
								null,
								sortOrder);
		
		//---register to watch a content URI for changes---
		c.setNotificationUri(getContext().getContentResolver(), uri);
		return c;
	}
	
	@Override
	public int update(Uri uri, ContentValues values, String selection,
		String[] selectionArgs) {
		
		int count = 0;
		switch (uriMatcher.match(uri)){
//			case MOVIE_ID:
//				return "vnd.android.cursor.item/vnd.example.movies";

			case MOVIES:
				count = moviesDB.update(
									DATABASE_TABLE,
									values,
									selection,
									selectionArgs);
				break;
			case MOVIE_ID:
//			case MOVIE_ID:
//				return "vnd.android.cursor.item/vnd.example.movies";

			count = moviesDB.update(
									DATABASE_TABLE,
									values,
									_ID + " = " + uri.getPathSegments().get(1) +
									(!TextUtils.isEmpty(selection) ? " AND (" +
											selection + ')' : ""),
											selectionArgs);
				break;
			default: throw new IllegalArgumentException("Unknown URI " + uri);
		}
		getContext().getContentResolver().notifyChange(uri, null);
		return count;
	}
		
}


/*

String url = "content://sms/";
        Uri uri = Uri.parse(url);
        getContentResolver().registerContentObserver(uri, true, new MyContentObserver(handler));

        /uriSms = Uri.parse("content://sms/inbox");
        Cursor c = getContentResolver().query(uriSms, null,null,null,null);

        //Log.d("COUNT", "Inbox count : " + c.getCount());


}

class MyContentObserver extends ContentObserver {

    public MyContentObserver(Handler handler) {

        super(handler);

    }

@Override public boolean deliverSelfNotifications() {
    return false;
    }

@Override public void onChange(boolean arg0) {
    super.onChange(arg0);

     Log.v("SMS", "Notification on SMS observer");

    Message msg = new Message();
    msg.obj = "xxxxxxxxxx";

    handler.sendMessage(msg);

    Uri uriSMSURI = Uri.parse("content://sms/");
    Cursor cur = getContentResolver().query(uriSMSURI, null, null,
                 null, null);
    cur.moveToNext();
    String protocol = cur.getString(cur.getColumnIndex("protocol"));
    if(protocol == null){
           Log.d("SMS", "SMS SEND");
           int threadId = cur.getInt(cur.getColumnIndex("thread_id"));
           Log.d("SMS", "SMS SEND ID = " + threadId);
           getContentResolver().delete(Uri.parse("content://sms/conversations/" + threadId), null, null);

    }
    else{
        Log.d("SMS", "SMS RECIEVE");
         int threadIdIn = cur.getInt(cur.getColumnIndex("thread_id"));
         getContentResolver().delete(Uri.parse("content://sms/conversations/" + threadIdIn), null, null);
    }

}
 */

/*
TODO: DOC
 */