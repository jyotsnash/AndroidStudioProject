// Maintains a ref to an object of type implementor
// defines the abstract interface
// Bridge is designed up-front to let the abstraction and the implementation vary independently
// . Adapter is retrofitted to make unrelated classes work together.
 

public class Stack {
	private StackImpl impl;
	
    public Stack( String s ) {
    	
        if      (s.equals("array")) impl = new StackArray(); // dlna
        else if (s.equals("list"))  impl = new StackList();  // wifi
        
        else System.out.println( "Stack: unknown parameter" );
    }
    public Stack()                { this( "array" ); }
    
    public void    push( int in ) { impl.push( in ); } // 4 fun in dlna/wifi
    public int     pop()          { return impl.pop(); }
    public int     top()          { return impl.top(); }// get the built stack info return back
    public boolean isEmpty()      { return impl.isEmpty(); }
    public boolean isFull()       { return impl.isFull(); }

}
