
public class StackFIFO  extends Stack {
    private StackImpl temp = new StackList();
    public StackFIFO() {
        super( "array"); // so push can be taken care off ....
    }
    public StackFIFO( String s ) {
        super( s );
    }
    public int pop() {
    	
    	// get all elements from bottom push it in stack so that it sinverted
    	// then pop it out to get sequential no's
    	// get 12 & push : get 11 & push : get 10 & push ... get 1 & push
        while ( ! isEmpty()) {
            temp.push( super.pop() ); // calling StackArray.pop
            
        }
        int ret =  temp.pop();
        
        // Now the entire list is inverted get the data bask as 1 2 3 4 5 .. 10 11
        while ( ! temp.isEmpty()) {
            push( temp.pop() );
        }
        
        return ret;
    }
}