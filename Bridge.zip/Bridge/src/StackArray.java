// Extends interface defined by abstraction
// This defines only prmitive operations 
// The abstraction defines  higher level operations like StackFIFo
public  class StackArray  implements StackImpl {
    private int[] items = new int[12];
    private int   total = -1;
    
    
    public void push( int i ) {
        if ( ! isFull()) {
            items[++total] = i;
        }
       
       }
	@Override
	public int pop() {
		// TODO Auto-generated method stub
		if (isEmpty()) return -1;
        return items[total--];
    
	}
	@Override
	public int top() {
		// TODO Auto-generated method stub
	     if (isEmpty()) return -1;
         return items[total];
    
		
	}
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		 return total == -1;
	        
		
	}
	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		 return total == 11;
	        
	}
}