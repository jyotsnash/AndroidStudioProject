package projects.chythanya.userlogin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class UserHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);
        TextView userName = findViewById(R.id.name);
//this activity called only when user login is successful


// retrieve the user name to display on the welcome screen
        Bundle bundle = getIntent().getExtras();
        String name = bundle.getString("NAME_KEY");
        userName.setText(name);
    }
}
