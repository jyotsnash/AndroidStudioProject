package projects.chythanya.userlogin;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

import projects.chythanya.userlogin.Model.User;
import projects.chythanya.userlogin.ViewModel.userViewModel;

//Home screen for the Admin
public class HomeActivity extends AppCompatActivity {
    userViewModel viewModel;
    EditText userID,userName,Password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Button addUser = findViewById(R.id.addUser);
        Button displayUser = findViewById(R.id.Display_button);

        userID = findViewById(R.id.uID);
        userName = findViewById(R.id.uName);
        Password = findViewById(R.id.pass);

        viewModel = ViewModelProviders.of(this).get(userViewModel.class);

        //to add the user
        addUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user = new User(userID.getText().toString(),userName.getText().toString(),Password.getText().toString());
                viewModel.insertUser(user);

            }
        });
        //to display the users
        displayUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(HomeActivity.this,DisplayUser.class);
                startActivity(intent);
            }
        });
    }
}
