package projects.chythanya.userlogin.Model;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;


@Dao
public interface userDao {
    //get all the users
    @Query("SELECT * FROM User")
     LiveData<List<User>> getAllUsers();
    //get the user for the given userid and password
    @Query("SELECT * FROM User WHERE userId = :userid  ")
            User getUser(String userid);
    //insert the uesr in the database
    @Insert
    void insertUser(User user);

    //Delete all the user from the database
    @Query("DELETE FROM User")
    void deleteUsers();
    //Delete particular user from the datatabse
    @Query("DELETE FROM User WHERE userId = :userid")
    void deleteOneUser(String userid);
}
