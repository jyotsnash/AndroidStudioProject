package projects.chythanya.userlogin;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import projects.chythanya.userlogin.Model.User;
import projects.chythanya.userlogin.ViewModel.userViewModel;

public class MainActivity extends AppCompatActivity {
    EditText UserId, Password;
    Button Login;
    public userViewModel mviewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UserId = findViewById(R.id.userId);
        Password = findViewById(R.id.password);
        Login = findViewById(R.id.Login_button);
        mviewModel = ViewModelProviders.of(this).get(userViewModel.class);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//*************************************************************************************
//                GET THE USER DETAILS FROM THE DATABASE
//                *********************************************************************
                User user = mviewModel.getUser(UserId.getText().toString());
                if (user != null){
                  String  name = user.getUserName();
                   String pass = user.getPassword();
//
                    if(pass != null && pass.equals(Password.getText().toString()) ){
                        Intent intent = new Intent(MainActivity.this,UserHome.class);
                        intent.putExtra("NAME_KEY",name);
                        startActivity(intent);
                    }
                //**********************************
// Admin name and password hard coded for testing purpose
                //***********************************

                }
                if(UserId.getText().toString() != null && UserId.getText().toString().equals("Admin") &&
                        Password.getText().toString().equals("123")) {
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    startActivity(intent);
                }

            }
        });
    }
}
