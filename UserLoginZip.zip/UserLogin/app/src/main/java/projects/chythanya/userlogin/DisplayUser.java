package projects.chythanya.userlogin;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.List;

import projects.chythanya.userlogin.Model.User;
import projects.chythanya.userlogin.ViewModel.userViewModel;

public class DisplayUser extends AppCompatActivity {
    private userViewModel mViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_user);
        RecyclerView recyclerView = findViewById(R.id.RecyclerView);

        //For testing the updation of live data
        final RecyclerAdapter recyclerAdapter = new RecyclerAdapter(this);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //View Model
        mViewModel = ViewModelProviders.of(this).get(userViewModel.class);
        //obser the changes in the live data and set the latest data to the adapter
        mViewModel.getsUsers().observe(this, new Observer<List<User>>() {
            @Override
            public void onChanged(@Nullable List<User> users) {
                recyclerAdapter.setUsers(users);
            }
        });


    }
}
