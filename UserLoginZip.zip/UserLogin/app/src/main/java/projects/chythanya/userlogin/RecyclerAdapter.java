package projects.chythanya.userlogin;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import projects.chythanya.userlogin.Model.User;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {
    private  List<User> muserList;
    private Context mcontext;

    RecyclerAdapter(Context context){

        mcontext = context;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mcontext).inflate(R.layout.itm_list,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public int getItemCount() {

        if(muserList != null){
            return muserList.size();
        }else{
            return 0;
        }
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        if (muserList !=null){
            User user = muserList.get(position);
            holder.textView.setText(user.getUserName());
        }else{
            holder.textView.setText("User Data not available");
        }



    }
//method used to set the live data
    public void setUsers(List<User> userList) {
        this.muserList = userList;
        notifyDataSetChanged();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView textView;

        public MyViewHolder(View itemView) {
                    super(itemView);
            textView = itemView.findViewById(R.id.userDetails);
        }
    }
}
