package com.edu.sqldemo;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

     // Butter knife

    //1.  declare my wedigets.. EditText button..
    private ListView studentListVieww;
    EditText editTextName,editTextAge ;

    private StudentUtility studentUtility;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inject Butter knife
        ButterKnife.bind(this);

        /// 2.    find view by id ....

//        Button insertButton = (Button) findViewById(R.id.insertButton);
//        Button readButton   = (Button) findViewById(R.id.readButton);
//        Button updateButton = (Button) findViewById(R.id.updateButton);
//        Button deleteButton = (Button) findViewById(R.id.deleteButton);

        editTextName        =( EditText)findViewById(R.id.editTextName);

        editTextAge        =( EditText)findViewById(R.id.editTextAge);

        studentListVieww    = (ListView) findViewById(R.id.studentListView);

        studentUtility = new StudentUtility(this);
        studentUtility.open();

        // 3.   add a listener to my buttonHandlers


//        insertButton.setOnClickListener(this);
//        readButton.setOnClickListener(this);
//        updateButton.setOnClickListener(this);
//        deleteButton.setOnClickListener(this);

//        insertButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });







    }
    /// 4. onClick()
    // process the buttons..

//    @Override
//    public void onClick(View v) {
//
//
//        switch(v.getId()){
//
////            case R.id.insertButton:
////                insertRecords();
////                break;
//            case R.id.readButton:
//
//                readRecordsByToast();
//                //readRecords();   // Usage of SimpleCursorAdapter
//                break;
//            case R.id.updateButton:
//
//                updateRecords();
//                break;
//            case R.id.deleteButton:
//                 deleteRecords();
//
//               // deleteAllrecordsFromDB();
//                break;
//
//
//        }
//
//
//    }



    // Room  -----> better way to deal with SQL much simpler 100 lines of code is converted into 2 lines
    // ViewModel  ---> Take care of android lifecycle issues..: all the local variables of android is taken care of by viewmodel
    // LiveData    ---> When there is a change to the master data base.. the subscribed users are notified...


    @OnClick(R.id.readButton)
public void readRecords() {

       // studentUtility.listStudentsByToast();


        Cursor cursor = studentUtility.listStudents();

        // recycler view....

        if (cursor != null) {

            String[] from = new String[]{StudentUtility.COLUMN_NAME, StudentUtility.COLUMN_AGE};
            int[]      to = new int[]{android.R.id.text1, android.R.id.text2};

            android.support.v4.widget.SimpleCursorAdapter simpleCursorAdapter = new android.support.v4.widget.SimpleCursorAdapter(
                    this, android.R.layout.simple_list_item_2, cursor, from, to, 0);
            studentListVieww.setAdapter(simpleCursorAdapter);
        }






    }
    @OnClick(R.id.deleteButton)
    public void deleteRecords() {

        //studentUtility.deteAstudent(new Student(editTextName.getText().toString(),editTextAge.getText().toString() ));

        studentUtility.deteAllStudents();
    }

   public void deleteAllrecordsFromDB() {
    }
    @OnClick(R.id.updateButton)
    public void updateRecords() {

        studentUtility.UpdateStudent(new Student(editTextName.getText().toString(),editTextAge.getText().toString() ));

    }



    @OnClick(R.id.insertButton)
    public void insertRecords() {


        studentUtility.addStudent(new Student(editTextName.getText().toString(),editTextAge.getText().toString() ));
        Toast.makeText(this, "Clicked on Insert records..", Toast.LENGTH_SHORT).show();
    }


}
