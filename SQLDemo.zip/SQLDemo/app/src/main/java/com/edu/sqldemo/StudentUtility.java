package com.edu.sqldemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

public class StudentUtility {


    // Oracle -> will not work in Android
    // SQLite -> lighter ver of DB
    // RELM
    // Cupboard
    // ROOM -> latest and the best..

    // 1000 rec..  give it to the cloud... mil records.. Oracle servers can pull and push

    // Wrapper class for My DB class

   public  static  final String DB_NAME ="students.db"; // t will be stored in internal file system


    //                     My Students

    //    Pri__key     name             age         address
    //    1            Jatin            19
    //    2            Rahul            21
    //    3            Subhash          20


    public  static  final String TABLE_NAME ="studentss";


    // Fields
    public  static  final String  COLUMN_ID = "_id";
    public  static  final String  COLUMN_NAME  = "name";
    public  static  final String   COLUMN_AGE  ="age";

    // ver
    public  static  final int DB_VERSION = 1 ;


    private static final String TABLE_CREATE_QUERY =
            "create table " + TABLE_NAME + "(" + COLUMN_ID + " integer primary key autoincrement," + COLUMN_NAME + " text," +
                    COLUMN_AGE + " text);";

   // "create table studentss ( _id  integer primary key autoincrement, name  text ,age text"


    private  StudentDatabaseUtility databaseUtility;
    private  SQLiteDatabase         sqLiteDatabase; // holds read and write permissions

    private Context context ;   // can hold this

    private MainActivity mainActivity; //  NEW  // can hold this

    public StudentUtility(MainActivity mainActivity) {

//        this.context = mainActivity;

        this.context= mainActivity;
        databaseUtility = new StudentDatabaseUtility(context);

    }

    public void open() {

        sqLiteDatabase = databaseUtility.getWritableDatabase();
        //   sqLiteDatabase points to all the CRUD operations

    }

    ///   Business Logic   CRUD operations...


    public void addStudent(Student student) {

        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME,student.name);
        values.put(COLUMN_AGE,student.age);

        long id = sqLiteDatabase.insert(TABLE_NAME,null,values);

        if( id != -1 ) {
            Toast.makeText(context, "Insert Success "+id, Toast.LENGTH_SHORT).show();
        }


    }

    public void listStudentsByToast() {

        Cursor cursor = sqLiteDatabase.query(TABLE_NAME,null,null,null,
                                null,null,null);

        if( cursor != null && cursor.moveToFirst()) {

            do {

                String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
                String age = cursor.getString(cursor.getColumnIndex(COLUMN_AGE));

                Toast.makeText(context, "Name :"+name+" Age : "+age, Toast.LENGTH_SHORT).show();




            }while( cursor.moveToNext());
        }

        if( cursor != null) {
            cursor.close();
        }
    }

    public void UpdateStudent(Student student) {

        ContentValues values = new ContentValues();

       // update the record by a student AGE..
        values.put(COLUMN_AGE,student.age);

        int numRowsUpdated = sqLiteDatabase.update(TABLE_NAME,values,COLUMN_NAME +
                "=?",new String[]{student.name}
                );

        Toast.makeText(context, " No of records Updated = "+numRowsUpdated, Toast.LENGTH_SHORT).show();

    }

    public void deteAstudent(Student student) {

        int numRowsDeleted = sqLiteDatabase.delete(TABLE_NAME,COLUMN_NAME +
                "=?",new String[]{student.name}
        );

        Toast.makeText(context, " No of records Deleted= "+numRowsDeleted, Toast.LENGTH_SHORT).show();

    }

    public void deteAllStudents() {

        sqLiteDatabase.delete(TABLE_NAME,null,null);
        Toast.makeText(context, "Deleted all the students..", Toast.LENGTH_SHORT).show();
    }

    public Cursor listStudents() {

        Cursor cursor = sqLiteDatabase.query(TABLE_NAME,null,null,null,
                null,null,null);

        return  cursor;

    }

    // Core data base///////
    private class StudentDatabaseUtility extends SQLiteOpenHelper {


        public StudentDatabaseUtility( Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL(TABLE_CREATE_QUERY);

        }

        // whenever ver changes... 1 to 2 & >>>>>>> 3.4.5.6.7.8.9
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            Log.w("Contentdatabase",
                    "Upgrading database from version "
                            + oldVersion + " to " + newVersion
                            + ", which will destroy all old data");

            db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
            onCreate(db);


        }
    }

}
