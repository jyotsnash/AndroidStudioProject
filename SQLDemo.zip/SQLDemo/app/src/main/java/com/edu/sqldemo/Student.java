package com.edu.sqldemo;

public class Student {

    public  final String name ;
    public final String age ;

    public Student(String name, String age) {
        this.name = name;
        this.age = age;
    }
}
