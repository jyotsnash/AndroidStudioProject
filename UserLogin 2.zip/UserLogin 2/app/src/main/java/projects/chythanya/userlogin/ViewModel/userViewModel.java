package projects.chythanya.userlogin.ViewModel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

import projects.chythanya.userlogin.Model.User;
import projects.chythanya.userlogin.Model.userRepository;

public class userViewModel extends AndroidViewModel {

    private userRepository muserRepository;
   public final  LiveData<List<User>> mAllusers;


    //required constructor
    public userViewModel(@NonNull Application application) {
        super(application);

        muserRepository = new userRepository(application);
        mAllusers = muserRepository.getUsers();
    }
    //get all users
    public LiveData<List<User>> getsUsers(){
        return mAllusers;
    }
    //insert user
    public void insertUser(User user){
        muserRepository.insertUser(user);
    }
  //get the user
    public User getUser(String userid){ return muserRepository.getUser(userid);}
    //delete user
    public void deleteUSer(String userid){
        muserRepository.deleteUser(userid);
    }
}
