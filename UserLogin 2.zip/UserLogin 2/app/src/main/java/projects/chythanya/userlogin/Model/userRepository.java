package projects.chythanya.userlogin.Model;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;
import android.widget.ProgressBar;

import java.util.List;

import projects.chythanya.userlogin.MainActivity;

public class userRepository {
    private userDao muserdao;
    private LiveData<List<User>> allUsers;
    private User userVal;

    //constructor to  handle the db and initialize the member variables
    public userRepository(Application application){
        UserDatabase userDatabase = UserDatabase.getDatabase(application);
        muserdao = userDatabase.userDao();
        allUsers = muserdao.getAllUsers();
    }

    public LiveData<List<User>> getUsers(){
        return allUsers;
    }

    public void insertUser(User user){
        new insertAsynTask(muserdao).execute(user);
    }

    private class insertAsynTask extends AsyncTask<User,Void,Void> {
    private userDao mAsyncUserDao;

        public insertAsynTask(userDao userDao){
            this.mAsyncUserDao = userDao;

        }

        @Override
        protected Void doInBackground(User... users) {
            mAsyncUserDao.insertUser(users[0]);
            return null;

        }
    }
public User getUser(String userID){
        new GetUserAsyncTask(muserdao).execute(userID);
        return userVal;
}

    public void deleteUser(String userid){
        new deleteAsynTask(muserdao).execute();
    }

    private static class deleteAsynTask extends AsyncTask<String,Void,Void>{
        private userDao mdelAsynDao;

       public deleteAsynTask(userDao userdao){
           this.mdelAsynDao = userdao;
       }

        @Override
        protected Void doInBackground(String... strings) {
           mdelAsynDao.deleteOneUser(strings[0]);
            return null;
        }
    }

    private class GetUserAsyncTask extends AsyncTask<String,Void,User> {
        private userDao mgetNameDao;
        public GetUserAsyncTask(userDao muserdao) {
            this.mgetNameDao =  muserdao;
        }

        @Override
        protected User doInBackground(String... strings) {
            User user = mgetNameDao.getUser(strings[0]);
            return user;
        }

        @Override
        protected void onPostExecute(User user) {
//            super.onPostExecute(user);
            userVal = user;
        }
    }

}
