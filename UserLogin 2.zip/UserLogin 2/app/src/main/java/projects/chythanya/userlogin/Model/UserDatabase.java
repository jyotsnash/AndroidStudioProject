package projects.chythanya.userlogin.Model;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities = {User.class},version = 1)
public abstract class UserDatabase extends RoomDatabase {
    public abstract userDao userDao();
    public static UserDatabase INSTANCE;

    public static UserDatabase getDatabase(final Context context){
        if(INSTANCE ==null){
            synchronized (UserDatabase.class){
                if(INSTANCE==null){
                    //build the database
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),UserDatabase.class,"user_data").build();

                }
            }

        }
        return INSTANCE;
    }
}
