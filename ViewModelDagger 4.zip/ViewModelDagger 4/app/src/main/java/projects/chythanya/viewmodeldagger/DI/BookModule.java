package projects.chythanya.viewmodeldagger.DI;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;
import projects.chythanya.viewmodeldagger.View.MainActivity;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;
import projects.chythanya.viewmodeldagger.ViewModel.bookViewModel;

//this is the provider class. it contains all the methods which are provided for injecting

@Module
public class BookModule {
    private MyApplication mMyApplication;

    BookModule(MyApplication application){
        mMyApplication = application;
    }

    //this provides the book object, and only single instance is created
    //this is internally injected by dagger while creating repository object
    @Provides
    @Singleton
    Book provideBook() {
        return new Book();
    }
    //this provides the repository object, and only single instance is created
    //this is internally injected by dagger framework while creating the viewmodel factory object
    @Provides
    @Singleton
    repository providerepository(){
        return new repository(new Book());

    }
    //this provides the object for view model, only single instance is created
    //this is injected in the main activity
    @Provides
    @Singleton
    ViewModelFactory providefactory(){
        return new ViewModelFactory(new repository (new Book()));
    }



}
