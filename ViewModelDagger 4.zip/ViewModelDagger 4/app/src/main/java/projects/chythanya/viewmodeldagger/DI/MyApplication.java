package projects.chythanya.viewmodeldagger.DI;


import android.app.Application;

import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;

//aplication class to be used to access the component
public class MyApplication extends Application {
    private BookComponent component;

    @Override
    public void onCreate() {
        super.onCreate();
        component = createMyComponent();
    }

    public BookComponent getComponent(){
        return component;
    }

    private BookComponent createMyComponent() {

        return DaggerBookComponent.builder().
                bookModule(new BookModule(this)).build();//builds the component
    }
}
