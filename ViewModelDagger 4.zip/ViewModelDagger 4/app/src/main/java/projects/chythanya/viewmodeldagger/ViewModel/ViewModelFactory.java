package projects.chythanya.viewmodeldagger.ViewModel;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.support.annotation.NonNull;

import projects.chythanya.viewmodeldagger.Model.repository;

public class ViewModelFactory implements ViewModelProvider.Factory {
    private repository mrepository;

   public ViewModelFactory(repository repo){
        mrepository = repo;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if(modelClass.isAssignableFrom(bookViewModel.class)){
            return (T) new bookViewModel(mrepository);
        }
        else if(modelClass.isAssignableFrom(PriceViewModel.class)){
            return (T) new PriceViewModel(mrepository);
        }
        throw new IllegalArgumentException("View model not available");
    }
}
