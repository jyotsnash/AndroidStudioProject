package projects.chythanya.viewmodeldagger.View;

import android.arch.lifecycle.ViewModelProviders;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import projects.chythanya.viewmodeldagger.DI.MyApplication;
import projects.chythanya.viewmodeldagger.R;
import projects.chythanya.viewmodeldagger.ViewModel.PriceViewModel;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;

public class PriceActivity extends AppCompatActivity {
    @BindView(R.id.et_price)
    protected EditText price;

    @BindView(R.id.et_quantity)
    protected  EditText quantity;

    @BindView(R.id.tv_totPrice)
    protected TextView totalPrice;

    @Inject
    ViewModelFactory factory;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_price);


        ((MyApplication) getApplication()).getComponent().inject(this);

        ButterKnife.bind(this);
    }
    @OnClick(R.id.bt_getPrice)
    public void getTotalPrice(View view){
        PriceViewModel priceViewModel = ViewModelProviders.of(this,factory).get(PriceViewModel.class);
//        int n1=0;int n2=0;
//        try {
////            n1 = ;
////            n2 = ;
//        }
//        catch (NumberFormatException e){
//            e.printStackTrace();
//        }
        int totPrice = priceViewModel.getTotalPrice(Integer.parseInt(price.getText().toString()),
                                                    Integer.parseInt(quantity.getText().toString()));
    totalPrice.setText(String.valueOf(totPrice));
    }
}
