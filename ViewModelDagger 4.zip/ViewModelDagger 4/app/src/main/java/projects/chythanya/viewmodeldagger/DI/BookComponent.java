package projects.chythanya.viewmodeldagger.DI;

import android.app.Application;

import javax.inject.Singleton;

import dagger.Component;
import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;
import projects.chythanya.viewmodeldagger.View.MainActivity;
import projects.chythanya.viewmodeldagger.View.PriceActivity;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;
import projects.chythanya.viewmodeldagger.ViewModel.bookViewModel;

//only single instance of the interface is created
//it acts as a bridge between the provider(module) and the consumer(mainActivity)

@Singleton
@Component(modules = BookModule.class)
public interface BookComponent {
//this is the method we are injecting into mainactivity
    ViewModelFactory provideViewModelFactory();


    // This acts as visitor adapter.. so dagger can revisit..

//    bookViewModel provideViewModel();

    void inject(MainActivity  main);           //injecting in mainActivity
    void inject(PriceActivity priceActivity);  //injecting in PriceActivity
   
}
