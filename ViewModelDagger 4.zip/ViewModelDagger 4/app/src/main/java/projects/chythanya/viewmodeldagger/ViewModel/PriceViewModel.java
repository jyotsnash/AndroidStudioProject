package projects.chythanya.viewmodeldagger.ViewModel;

import android.arch.lifecycle.ViewModel;

import projects.chythanya.viewmodeldagger.Model.repository;

public class PriceViewModel extends ViewModel {

    private projects.chythanya.viewmodeldagger.Model.repository repository;

    PriceViewModel(repository repo){
        repository = repo;
    }
    public int getTotalPrice(int n1, int n2){
      return  repository.getTotalPrice(n1,n2);
    }
}
