package projects.chythanya.viewmodeldagger.Model;

import javax.inject.Inject;

public class repository {
    private Book mbook;


   public repository(Book book){
        mbook = book;
        mbook.setTitle("Book title Android Developers");
        mbook.setAuthor("Book Author Meeee...");
    }

public String getTitle(){
        String title = mbook.getTitle();
        return title;
}
public String getAuthor(){
        return mbook.getAuthor();
}

public int getTotalPrice(int n1, int n2){
       return n1 * n2;
}

}
