package projects.chythanya.viewmodeldagger.DI;

import android.arch.lifecycle.ViewModel;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Map;

import javax.inject.Provider;

import dagger.MapKey;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.IntoMap;
import projects.chythanya.viewmodeldagger.Model.repository;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;
import projects.chythanya.viewmodeldagger.ViewModel.bookDisplayViewModel;
import projects.chythanya.viewmodeldagger.ViewModel.bookViewModel;

@Module
public class ViewModelModule {
    /*
    http://tutorials.jenkov.com/java/annotations.html
    @REtention-->You can specify for your custom annotation if it should be available at runtime,
     for inspection via reflection.
      You do so by annotating your annotation definition with the @Retention annotation.

      @Target-->You can specify which Java elements your custom annotation can be used to annotate.
      You do so by annotating your annotation definition with the @Target annotation.

https://google.github.io/dagger/api/2.11/dagger/MapKey.html
      @Mapkey-->Identifies annotation types that are used to associate keys with values returned by provider methods in order to compose a map.
Every provider method annotated with @Provides and @IntoMap must also have an annotation that identifies the key for that map entry.
That annotation's type must be annotated with @MapKey.

Typically, the key annotation has a single member, whose value is used as the map key.

For example, to add an entry to a Map<SomeEnum, Integer> with key SomeEnum.FOO, you could use an annotation called @SomeEnumKey:
     */
    /*
    ViewModelKey annotation, when used on provider methods,
    basically says that the services returned by these methods must be put into special Map.
     The keys in this Map will be of type Class<? extends ViewModel> and
     the values will be of type <? extends ViewModel> (subclass of ViewModel).
     */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.RUNTIME)
    @MapKey
    @interface ViewModelKey {
        Class<? extends ViewModel> value();
    }
/*
Factory retrieves the required Provider object from the Map, calls its get() method,
casts the obtained reference to the required type and returns it.
The nice thing about it is that this code is independent of the actual types of ViewModels in your application,
so you don’t need to change anything here when you add new ViewModel classes.
Now, to add new ViewModel, you’ll simply add the respective provider method:
 */
    @Provides
    ViewModelFactory viewModelFactory(Map<Class<? extends ViewModel>, Provider<ViewModel>> providerMap) {
        return new ViewModelFactory(providerMap);
    }
/*
@IntoMap annotation says that Provider object for this service will be inserted into Map,
and @ViewModelKey annotation specifies under which key it will reside.
Dagger will create implicit Map data structure filled with Provider<ViewModel> objects and put it onto the objects graph.
You can make use of that Map by passing it into ViewModelFactory
 */
    @Provides
    @IntoMap
    @ViewModelKey(bookViewModel.class)
    ViewModel bookViewModel(repository repo) {
        return new bookViewModel(repo);
    }

    @Provides
    @IntoMap
    @ViewModelKey(bookDisplayViewModel.class)
    ViewModel bookDisplayViewModel(repository repo) {
        return new bookDisplayViewModel(repo);
    }
}
