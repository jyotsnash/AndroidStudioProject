package projects.chythanya.viewmodeldagger.DI;

import android.app.Application;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.BookDao;
import projects.chythanya.viewmodeldagger.Model.BookDatabase;
import projects.chythanya.viewmodeldagger.Model.repository;
import projects.chythanya.viewmodeldagger.View.MainActivity;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;
import projects.chythanya.viewmodeldagger.ViewModel.bookViewModel;

//this is the provider class. it contains all the methods which are provided for injecting

@Module
@Singleton
public class BookModule {
    private final BookDatabase bookDatabase;
//Book module needs an application to instantiate the class
    //we build the database right here in the module
    public BookModule(Application application){
        this.bookDatabase = Room.databaseBuilder(application,BookDatabase.class,"BookDetails.db").build();
    }
    /*
    On removing the provide annotation on the method provide database, this is the error generated
    error: projects.chythanya.viewmodeldagger.Model.BookDatabase cannot be provided without an @Provides-annotated method.
projects.chythanya.viewmodeldagger.Model.BookDatabase is injected at
projects.chythanya.viewmodeldagger.DI.BookModule.provideBookDao(bookDatabase)
projects.chythanya.viewmodeldagger.Model.BookDao is injected at
projects.chythanya.viewmodeldagger.DI.BookModule.providerepository(bookDao)
     */
    //provides the database to be used by Dao
    @Provides

BookDatabase provideBookDatabase(Application application){
        return bookDatabase;
}

//provides the Dao to be used by repository
@Provides

BookDao provideBookDao(BookDatabase bookDatabase){
        return bookDatabase.BookDao();
}
    //this provides the repository object, and only single instance is created
    //this is internally injected by dagger framework while creating the viewmodel factory object
/*
on removing provide annotation to the repository this is the compile time error getting generated.
error: projects.chythanya.viewmodeldagger.Model.repository cannot be provided without an @Inject constructor or from an @Provides-annotated method.
projects.chythanya.viewmodeldagger.Model.repository is injected at
projects.chythanya.viewmodeldagger.DI.ViewModelModule.bookViewModel(repo)
java.util.Map<java.lang.Class<? extends android.arch.lifecycle.ViewModel>,javax.inject.Provider<android.arch.lifecycle.ViewModel>> is injected at
projects.chythanya.viewmodeldagger.DI.ViewModelModule.viewModelFactory(providerMap)
projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory is injected at
projects.chythanya.viewmodeldagger.View.MainActivity.factory
projects.chythanya.viewmodeldagger.View.MainActivity is injected at
projects.chythanya.viewmodeldagger.DI.BookComponent.inject(main)
 */
    @Provides
        repository providerepository(BookDao bookDao){
        return new repository(bookDao);
    }
    //this provides the object for view model, only single instance is created
    //this is injected in the main activity
    /* instead if providing the view model factory we provie the view models which het injected into the view model factory
    @Provides
      ViewModelFactory providefactory(repository repo){

        return new ViewModelFactory(repo);
    }
*/


}
