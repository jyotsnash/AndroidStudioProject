package projects.chythanya.viewmodeldagger.View;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import projects.chythanya.viewmodeldagger.DI.BookComponent;
//import projects.chythanya.viewmodeldagger.DI.DaggerBookComponent;
import projects.chythanya.viewmodeldagger.DI.MyApplication;
import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.R;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;
import projects.chythanya.viewmodeldagger.ViewModel.bookViewModel;
/*
        DI

      Module
      component
      inject

      Prop of App

      Which class has to be exposed to DI and Why ?
    1. repository which is a dependency for the view models
         @Inject
            public repository (BookDao bookDao){
            this.bookDao = bookDao; }

     2. Dependency is as follows:
     Repository and Database takes application context in their constructor. --reffered this link:https://codelabs.developers.google.com/codelabs/android-room-with-a-view/#7

     3. Why use dagger???
     Instead of passing the context to repository and database,
     We pass the application context to the dagger (DON'T KNOW IF THIS IS THE RIGHT APPROACH).
     4. Book module is a singleton provider class (@Module)
     using application context we create the database within the dagger
      public BookModule(Application application){
        this.bookDatabase = Room.databaseBuilder(application,BookDatabase.class,"BookDetails.db").build();
    }
     The dagger module provides the database to DAO
     BookDao provideBookDao(BookDatabase bookDatabase){
        return bookDatabase.BookDao();
}
    The dagger module provides the DAO to repository,
      repository providerepository(BookDao bookDao){
        return new repository(bookDao);
    }
    The dagger module injects the repository to ViewModel Factory to create the view models
  @Inject
  public repository (BookDao bookDao){
      this.bookDao = bookDao;
  }
  5. How Dagger is implemented??
  -->It has two module classes(Application module, book module) which are providers of the methods for injecting
  Application module: It takes the application in the constructor and provides the application object.
  BookModule: it takes the application provided by the application module, and it provides the below objects:
  database, DAO, repository.
  --->It has one component(BookComponent), this acts as the bridge between the module classes and the activities(Main activity and DisplayActivity)
  It is an interface which exposes the application by which we get handle of component and vis component we inject the methods in activities
---> It has an application(MyApplication) which extends application,during compile time interface is implemented in a class daggerbookcomponent
and this implementation is held in this application.
 */
//this is the consumer class which needs the dependency injections
public class MainActivity extends AppCompatActivity {
@BindView(R.id.et_bookTitle)
protected EditText title;

@BindView(R.id.et_bookAuthor)
protected EditText author;

@BindView(R.id.et_price)
protected EditText price;

@BindView(R.id.rb_bookRating)
protected RatingBar rating;

@BindView(R.id.et_description)
protected EditText description;

//    *****************************changed code to inject view model directly instead of injecting viewmodel factory*********
    //here we are injecting the object of viewmodel factory, during the creation of the viewmodel factory repositor onject and book object
    //are internally injected by dagger.
@Inject
    ViewModelFactory factory;
/*
Factories are very useful constructs when you need to instantiate objects with runtime dependencies,
or when you need to instantiate many objects at runtime,
 or when the specific type of object that you’ll need isn’t known at compile time.
 Nothing of that applies in this case, however.
 You need one instance of ViewModel and you know its type and its dependencies at compile time.
 Therefore, usage of abstract factory pattern is unjustified in this case.

Unnecessary dependencies like ViewModelFactory violate fundamental principle of object-oriented design called
Law of Demeter.
Usually you can refactor the code to fix LoD violations,
but, in this case, it’s violated by ViewModel framework itself, so you can’t work around that.
It’s the violation of Law of Demeter that causes the troubles with respect to dependency injection.
Just think about it for a moment: you already have your ViewModels on the object graph,
but, instead of simply injecting them directly, you are forced to use ViewModelFactory. It’s a shame.
 */
    //****************************************end of changed code*********************************

    bookViewModel bookViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        *******************************changed code****************************************************
        //on building the app dagger generates builder and names it with "dagger" prefixed to component name
        //here we are instantiating component using the builder generated by dagger.

//        BookComponent component = DaggerBookComponent.builder().build();

        //here we are injecting the dependecies into main activity
        //instead of injecting the component directly into main activity
//        component.inject(this);
        //******************************end of changed code******************************************
        //get the component from the application
        /*
        we can now can get a reference to the implemented method in MainActivity
        by using the Inject annotation and a call to the Component’s inject method.
        Again, the Component is stored in the Application instance.
         */
        ((MyApplication)  getApplication()).getComponent().inject(this);

        //binding the butterknife to mainactivity
        ButterKnife.bind(this);

        //**************************************changed code to instantiate viewmodel****************
        //viewmodel is instantiated with the help of factory(which gets injected by dagger)
        bookViewModel = ViewModelProviders.of(this,factory).get(bookViewModel.class);
        //*************************end of changed to instantiate view model******************

//
          }


    @OnClick(R.id.bt_saveBook)
    public void saveBook(View view){
        //save the book details
        Book book = new Book (title.getText().toString(),author.getText().toString(),Float.valueOf(price.getText().toString()),rating.getRating(),description.getText().toString());
        bookViewModel.saveBook(book);

    }
    @OnClick(R.id.bt_deleteBook)
    public void deleteBook(View view){
        //delete book details
//        Book book = new Book(title.getText().toString(),author.getText().toString(),Float.valueOf(price.getText().toString()),rating.getRating(),description.getText().toString());
        bookViewModel.deleteBook(title.getText().toString());
    }

    @OnClick(R.id.bt_displayBooks)
    public void displayBooks(View view){
        //display books
       Intent intent = new Intent(this,DisplayBooksActivity.class);
       startActivity(intent);
    }
}
