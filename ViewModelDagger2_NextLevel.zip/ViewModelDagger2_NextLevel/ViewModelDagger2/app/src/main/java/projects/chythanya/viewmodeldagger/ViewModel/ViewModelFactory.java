package projects.chythanya.viewmodeldagger.ViewModel;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.support.annotation.NonNull;

import java.util.Map;

import javax.inject.Inject;
import javax.inject.Provider;

import projects.chythanya.viewmodeldagger.Model.repository;
/*
View model factory will generate a view model class but instead of having multiple if condition we use the viewmodule which provides us the
view model class type for which view model has to be created

public class ViewModelFactory implements ViewModelProvider.Factory {
    private repository mrepository;
   public ViewModelFactory(repository repo){
        mrepository = repo;
    }
    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
       //if condition
        if(modelClass.isAssignableFrom(bookViewModel.class)){
            return (T) new bookViewModel(mrepository);
        }
        else if(modelClass.isAssignableFrom(bookDisplayViewModel.class)){
            return (T) new bookDisplayViewModel(mrepository);
        }
        throw new IllegalArgumentException("View model not available");
    }
}
*/
public class ViewModelFactory implements ViewModelProvider.Factory {
    private final Map<Class<? extends ViewModel>, Provider<ViewModel>> mProviderMap;

    @Inject
    public ViewModelFactory(Map<Class<? extends ViewModel>, Provider<ViewModel>> providerMap) {
        mProviderMap = providerMap;
    }
    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) mProviderMap.get(modelClass).get();
    }
}