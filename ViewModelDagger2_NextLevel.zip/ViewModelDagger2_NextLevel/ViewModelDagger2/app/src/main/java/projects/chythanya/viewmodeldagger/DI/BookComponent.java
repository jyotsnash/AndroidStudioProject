package projects.chythanya.viewmodeldagger.DI;

import android.app.Application;

import javax.inject.Singleton;

import dagger.Component;
import projects.chythanya.viewmodeldagger.Model.repository;
import projects.chythanya.viewmodeldagger.View.DisplayBooksActivity;
import projects.chythanya.viewmodeldagger.View.MainActivity;
import projects.chythanya.viewmodeldagger.ViewModel.ViewModelFactory;


//only cingle instance of the interface is created
//it acts as a bridge between the provider(module) and the consumer(mainActivity)

@Singleton
@Component(modules = {ApplicationModule.class, BookModule.class, ViewModelModule.class})
public interface BookComponent {
//this is the method we are injecting into mainactivity
   // ViewModelFactory provideViewModelFactory();
//    bookViewModel provideViewModel();

   void inject(MainActivity main);//Book module will be use in mainActivity
   void inject(DisplayBooksActivity displayBooksActivity);//Book module will be used in DisplayBooksActivity


    Application application();//expose the api

}
