package projects.chythanya.viewmodeldagger.ViewModel;

import android.arch.core.util.Function;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.Transformations;
import android.arch.lifecycle.ViewModel;
import android.os.AsyncTask;

import java.util.List;

import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;

public class bookViewModel extends ViewModel {
    private repository mrepository;

   public bookViewModel(repository repo){
        mrepository = repo;
    }

                public void deleteBooks () {
//        mrepository.deleteBooks();
                deleteAllTask task = new deleteAllTask();
                task.execute();
            }


  public class deleteAllTask extends AsyncTask<Void,Void,Void>{

      @Override
      protected Void doInBackground(Void... voids) {
          mrepository.deleteBooks();
          return null;
      }
  }
  public void deleteBook(String title){
        DeleteTask task = new DeleteTask();
      task.execute(title);

  }
  public class DeleteTask extends AsyncTask<String ,Void,Void>{

      @Override
      protected Void doInBackground(String... strings) {
          mrepository.deleteBook(strings[0]);
          return null;
      }
  }

  public void saveBook(Book book){
//        mrepository.saveBook(book);
      insertTask task = new insertTask();
      task.execute(book);
  }

  public class insertTask extends AsyncTask<Book,Void,Void>{

      @Override
      protected Void doInBackground(Book... books) {
          mrepository.saveBook(books[0]);
          return null;
      }
  }

}
