package projects.chythanya.viewmodeldagger.Model;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;

@Dao
public interface BookDao {

    @Query("SELECT * FROM Book ")
    public LiveData<List<Book>> getBooks();

    @Insert(onConflict = REPLACE)
    public void saveBook(Book book);

    @Query("SELECT * FROM Book WHERE title = :title")
    public LiveData<Book> getBookDetails(String title);

    @Query("DELETE FROM Book")
    public void deleteBooks();

    @Query("DELETE FROM Book WHERE title = :title")
    public void deleteSingleBook(String title);

}
