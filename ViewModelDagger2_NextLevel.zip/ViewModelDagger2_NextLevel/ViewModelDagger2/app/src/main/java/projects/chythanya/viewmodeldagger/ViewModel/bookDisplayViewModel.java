package projects.chythanya.viewmodeldagger.ViewModel;

import android.arch.core.util.Function;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.Transformations;
import android.arch.lifecycle.ViewModel;

import java.util.List;

import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;

public class bookDisplayViewModel extends ViewModel {
    private repository mrepository;

  public  bookDisplayViewModel(repository repo){
        mrepository = repo;
    }

    public LiveData<List<Book>> getBooks(){
        LiveData<List<Book>> bookList = mrepository.getBooks();//gets the book list from the db
        bookList = Transformations.map(bookList, new Function<List<Book>, List<Book>>() {

            @Override
            public List<Book> apply(List<Book> input) {
                Book firstBook = input.get(0);//getting the first book in the list
                String bestSeller = firstBook.getTitle() + "- Best Seller";//adding best seller to the title
                firstBook.setTitle(bestSeller);//setting the changed title
                return input;//returning the book list with changes.
            }
        });
/*
        bookList = Transformations.switchMap(bookList, new Function<List<Book>, LiveData<List<Book>>>() {
            @Override
            public LiveData<List<Book>> apply(List<Book> input) {
                Book mybook = input.get(0);
                String title1 = mybook.getTitle();
                LiveData<Book> mbook = mrepository.getBook(title1);

                return input;
            }
        });
*/
        return bookList;//returning the booklist

      }



}
