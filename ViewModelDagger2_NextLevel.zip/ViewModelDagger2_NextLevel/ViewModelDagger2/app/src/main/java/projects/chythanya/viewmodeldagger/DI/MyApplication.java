package projects.chythanya.viewmodeldagger.DI;


import android.app.Application;

import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.Model.repository;

//aplication class to be used to access the component
/*
During compilation, Dagger 2 creates concrete class implementations triggered on the Component interfaces with names prefixed with Dagger,
e.g., DaggerBookComponent in this case.
As our application first starts,
we need to instantiate these classes and store them for use throughout our application.
We can extend Application for this purpose and update our AndroidManifest.xml to use it.
 */
public class MyApplication extends Application {
    private BookComponent component;

    @Override
    public void onCreate() {
        super.onCreate();
        component = createMyComponent();
    }

    public BookComponent getComponent(){
        return component;
    }

    private BookComponent createMyComponent() {
        return DaggerBookComponent.builder()
                .applicationModule(new ApplicationModule(this))
                .bookModule(new BookModule(this))
                //.viewModelModule
                .build();//builds the component
    }
}
