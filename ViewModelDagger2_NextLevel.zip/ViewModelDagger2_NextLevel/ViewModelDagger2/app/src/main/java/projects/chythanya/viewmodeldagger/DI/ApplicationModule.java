package projects.chythanya.viewmodeldagger.DI;

import android.app.Application;

import dagger.Module;
import dagger.Provides;

@Module
public class ApplicationModule {
    private final Application application;

    public ApplicationModule(MyApplication application){
        this.application = application;
    }
    @Provides
    Application provideApplication(){
        return application;
    }
}
