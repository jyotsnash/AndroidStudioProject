package projects.chythanya.viewmodeldagger.Model;

import android.arch.lifecycle.LiveData;

import java.util.List;

import javax.inject.Inject;

public class repository {
  private BookDao bookDao;


  public repository (BookDao bookDao){
      this.bookDao = bookDao;
  }


  public LiveData<List<Book>> getBooks(){
      return bookDao.getBooks();
  }

  public LiveData<Book> getBook(String title){
      return bookDao.getBookDetails(title);
  }

  public void deleteBook(String title){
      bookDao.deleteSingleBook(title);
  }
  public void deleteBooks(){
      bookDao.deleteBooks();
  }

  public void saveBook(Book book){
      bookDao.saveBook(book);
  }

}
