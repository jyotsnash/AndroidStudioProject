package projects.chythanya.viewmodeldagger.View;

import android.arch.lifecycle.LiveData;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.List;

import projects.chythanya.viewmodeldagger.Model.Book;
import projects.chythanya.viewmodeldagger.R;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.MyViewHolder> {
    private Context mcontext;
    private List<Book>mbookList;

    public BookAdapter(Context context){
        mcontext = context;
           }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mcontext).inflate(R.layout.row_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        if(mbookList != null) {
            Book book = mbookList.get(position);
            holder.title.setText(book.getTitle());
            holder.author.setText(book.getAuthor());
            holder.price.setText(String.valueOf(book.getPrice()));
            holder.rating.setRating(book.getRating());
            holder.desc.setText(book.getDesc());
        }
        else
        {
            holder.title.setText("No Books Found Yet ");
        }

    }
   public void setBookList(List<Book> booklist){
        mbookList = booklist;
        notifyDataSetChanged();

    }

    @Override
    public int getItemCount() {
        if (mbookList != null) {
            return mbookList.size();
        }
        else{
            return 0;
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView title, author, price, desc;
        private RatingBar rating;
        public MyViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tv_title);
            author = itemView.findViewById(R.id.tv_author);
            price = itemView.findViewById(R.id.tv_price);
            desc = itemView.findViewById(R.id.tv_desc);
            rating = itemView.findViewById(R.id.rb_rating);


        }
    }
}
