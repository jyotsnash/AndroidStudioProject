package com.example.calllogexample;
 
import android.app.Activity;
import android.os.Bundle;
import android.provider.CallLog;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
 
public class CallLogExampleActivity extends Activity {
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_log_example);
         
        Button addButton = (Button) findViewById(R.id.button1);
        addButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                  //Add number into calllog
                  long  callTimeInMiliSecond    = System.currentTimeMillis(); //time stamp

                  //CallLogUtility is the class where we have written our add/delete function
                  CallLogActivity utility = new CallLogActivity(); 
                  //number to add
                  String numberStr = "+919448384716";
                  utility.AddNumToCallLog(getBaseContext().getContentResolver(),numberStr,
                                                       CallLog.Calls.INCOMING_TYPE, callTimeInMiliSecond*30000);
            }
        });
         
        Button deleteButton = (Button) findViewById(R.id.button2);
        deleteButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //if you want to delete any number from call log then follow below 2 lines of code
                String numberStr = "+919448384716"; // delete this number from call log
                CallLogActivity utility = new CallLogActivity(); 
                utility.DeleteNumFromCallLog(getBaseContext().getContentResolver(), numberStr);
                }
        });
    }
 
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.call_log_example, menu);
        return true;
    }
 
}